import HeroCarousel from "../components/HeroCarousel";
import { WhatIs, Versus, Why, Trust, Featured, ProcessPreview, UseCases, FarmBand, ShareBand, FAQ } from "../components/sections";
import Contact from "./Contact";
import { useSEO } from "../hooks/useSEO";

export default function Home() {
  useSEO("Fresh microgreens", "Fresh microgreens grown with care by mini's greens.");
  return <>
    <div id="home"><HeroCarousel /></div>
    <WhatIs />
    <Versus />
    <div id="benefits"><Why /></div>
    <Trust />
    <Featured />
    <ProcessPreview />
    <UseCases all home />
    <FarmBand />
    <ShareBand />
    <FAQ />
    <div id="contact"><Contact /></div>
  </>;
}
