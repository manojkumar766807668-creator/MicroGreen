import { Link2 } from "lucide-react";
import { useToast } from "./ui";
import { copyLink } from "../utils/sharing";
export default function ShareButtons() {
  const [toast, show] = useToast();
  const url = window.location.href;
  return <div className="share">
    <span className="small">Share</span><button className="btn outline" type="button" onClick={() => copyLink(url, show)} aria-label="Copy product link"><Link2 size={18} /> Copy Link</button>{toast}</div>
}
